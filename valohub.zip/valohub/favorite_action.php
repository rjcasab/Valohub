<?php
session_start();
header('Content-Type: application/json');
include 'conexion.php';

if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

$userId = $_SESSION['usuario_id'];
$action = $_POST['action'] ?? '';
$type = $_POST['type'] ?? '';
$item = trim($_POST['item'] ?? '');

$allowed = ['campeon', 'arma', 'apartado'];

if (!$item || !in_array($type, $allowed, true) || $action !== 'toggle') {
    http_response_code(400);
    echo json_encode(['error' => 'Solicitud inválida']);
    exit;
}

$stmt = $conn->prepare("SELECT id FROM favoritos WHERE usuario_id = ? AND tipo = ? AND elemento = ?");
$stmt->bind_param("iss", $userId, $type, $item);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $delete = $conn->prepare("DELETE FROM favoritos WHERE id = ?");
    $delete->bind_param("i", $row['id']);
    $deleted = $delete->execute();
    $delete->close();

    if ($deleted) {
        echo json_encode(['success' => true, 'favorito' => false]);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'No se pudo eliminar el favorito']);
    }
} else {
    $insert = $conn->prepare("INSERT INTO favoritos (usuario_id, tipo, elemento) VALUES (?, ?, ?)");
    $insert->bind_param("iss", $userId, $type, $item);
    $inserted = $insert->execute();
    $insert->close();

    if ($inserted) {
        echo json_encode(['success' => true, 'favorito' => true]);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'No se pudo guardar el favorito']);
    }
}

$stmt->close();
$conn->close();

// Main JS - handling basic interactions and favoritos

document.addEventListener('DOMContentLoaded', () => {
    const loginBtns = document.querySelectorAll('.cta-btn, .btn-text');

    loginBtns.forEach(btn => {
        if (btn.closest('form')) return;

        btn.addEventListener('click', (e) => {
            if (btn.tagName !== 'A' || btn.getAttribute('href') === '#') {
                e.preventDefault();
            }
            btn.style.transform = 'scale(0.95)';
            setTimeout(() => {
                btn.style.transform = '';
            }, 100);
        });
    });

    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.borderColor = 'var(--primary-red)';
        });
        card.addEventListener('mouseleave', () => {
            card.style.borderColor = 'transparent';
        });
    });

    initializeChampionCardNavigation();
    initializeMapCardNavigation();

    if (window.loggedIn && window.favoritePageType) {
        const pageTypes = Array.isArray(window.favoritePageType) ? window.favoritePageType : [window.favoritePageType];
        pageTypes.forEach(type => initializeFavoriteButtons(type, window.initialFavorites || []));
    }
});

function initializeChampionCardNavigation() {
    const championCards = document.querySelectorAll('.champion-card');

    championCards.forEach(card => {
        card.addEventListener('click', (e) => {
            if (e.target.closest('.favorite-btn')) return;

            const championName = getCardDisplayName(card.querySelector('.champion-name'));
            if (!championName) return;

            window.location.href = `champion_detail.php?champion=${encodeURIComponent(championName.toLowerCase())}`;
        });
    });
}

function initializeMapCardNavigation() {
    const mapCards = document.querySelectorAll('.map-card');

    mapCards.forEach(card => {
        card.addEventListener('click', (e) => {
            if (e.target.closest('.favorite-btn')) return;

            const mapSlug = card.dataset.map || getCardSlug(card.querySelector('.map-name'));
            if (!mapSlug) return;

            window.location.href = `map_detail.php?map=${encodeURIComponent(mapSlug)}`;
        });
    });
}

function getCardDisplayName(nameEl) {
    if (!nameEl) return '';

    return nameEl.textContent.replace(/[★☆]/g, '').trim();
}

function getCardSlug(nameEl) {
    if (!nameEl) return '';
    return nameEl.textContent.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
}

function initializeFavoriteButtons(type, favorites = []) {
    const cardSelector = type === 'campeon' ? '.champion-card' : type === 'arma' ? '.weapon-card' : '.map-card';
    const cards = document.querySelectorAll(cardSelector);

    cards.forEach(card => {
        let itemLabel = '';
        let nameEl = null;
        if (type === 'campeon') {
            nameEl = card.querySelector('.champion-name');
            itemLabel = getCardDisplayName(nameEl);
        } else if (type === 'arma') {
            nameEl = card.querySelector('.weapon-name');
            itemLabel = getCardDisplayName(nameEl);
        } else if (type === 'apartado') {
            nameEl = card.querySelector('.map-name');
            itemLabel = getCardDisplayName(nameEl);
        }

        if (!itemLabel || !nameEl) return;

        const favoriteButton = document.createElement('button');
        favoriteButton.type = 'button';
        favoriteButton.className = 'favorite-btn';
        favoriteButton.dataset.favType = type;
        favoriteButton.dataset.favItem = itemLabel;

        const isFavorited = favorites.some(fav => fav.tipo === type && fav.elemento === itemLabel);
        if (isFavorited) {
            favoriteButton.classList.add('active');
            favoriteButton.innerHTML = '<span class="star-icon">★</span>';
        } else {
            favoriteButton.innerHTML = '<span class="star-icon">☆</span>';
        }

        favoriteButton.addEventListener('click', (e) => {
            e.stopPropagation();
            e.preventDefault();
            toggleFavorite(favoriteButton);
        });

        nameEl.appendChild(favoriteButton);
    });
}

function toggleFavorite(button) {
    const type = button.dataset.favType;
    const item = button.dataset.favItem;

    if (!type || !item) return;

    button.disabled = true;
    fetch('favorite_action.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
            action: 'toggle',
            type,
            item
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data && data.success) {
            if (data.favorito) {
                button.classList.add('active');
                button.innerHTML = '<span class="star-icon">★</span>';
            } else {
                button.classList.remove('active');
                button.innerHTML = '<span class="star-icon">☆</span>';
            }
            button.classList.add('pop');
            setTimeout(() => button.classList.remove('pop'), 300);
        }
    })
    .catch(console.error)
    .finally(() => {
        button.disabled = false;
    });
}

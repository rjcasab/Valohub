<?php
session_start();

$slug = strtolower(trim($_GET['champion'] ?? ''));
$slug = preg_replace('/[^a-z0-9_-]/', '', $slug);

if ($slug === '') {
    header('Location: champions.php');
    exit;
}

$imagePath = 'imagenes/' . $slug . '.png';

$championData = [
    'sage' => [
        'name' => 'SAGE',
        'role' => 'Centinela',
        'description' => 'Sage protege a su equipo con curación, barreras y control del espacio para mantener la ventaja en cualquier ronda.',
        'abilities' => [
            ['name' => 'Orbe de curación', 'description' => 'Cura a los aliados cercanos y les da tiempo para reagruparse.'],
            ['name' => 'Barrera', 'description' => 'Crea una barrera sólida para tapar accesos y proteger posiciones clave.'],
            ['name' => 'Alivio', 'description' => 'Reubica a un aliado de forma segura durante una situación peligrosa.'],
            ['name' => 'Resurrección', 'description' => 'Revive a un compañero caído con una rápida carga de habilidad.']
        ]
    ],
    'jett' => [
        'name' => 'JETT',
        'role' => 'Duelista',
        'description' => 'Jett se mueve con rapidez y precisión para tomar objetivos, crear ángulos de ataque y romper el flujo del enemigo.',
        'abilities' => [
            ['name' => 'Tormenta de dagas', 'description' => 'Lanza cuchillos que punzan y generan presión desde cualquier ángulo.'],
            ['name' => 'Ascenso', 'description' => 'Sube al aire para obtener una posición elevada y sorprender al rival.'],
            ['name' => 'Impulso', 'description' => 'Realiza un movimiento rápido en una dirección para entrar o salir de un enfrentamiento.'],
            ['name' => 'Tormenta de ceniza', 'description' => 'Aumenta la movilidad y el control de la zona con una gran cantidad de movilidad instantánea.']
        ]
    ],
    'omen' => [
        'name' => 'OMEN',
        'role' => 'Controlador',
        'description' => 'Omen domina el mapa con engaño, movilidad y control para forzar errores y romper la visión del equipo contrario.',
        'abilities' => [
            ['name' => 'Paranoia', 'description' => 'Lanza una esfera que deja ciega a los enemigos que la atraviesan.'],
            ['name' => 'Capa oscura', 'description' => 'Se vuelve invisible y se desplaza rápidamente hacia una nueva posición.'],
            ['name' => 'Viaje entre sombras', 'description' => 'Viaja entre sombras para tomar rutas inesperadas y atacar desde ángulos sorprendentes.'],
            ['name' => 'Decepción', 'description' => 'Crea una ilusión visual que distrae y obliga a reaccionar al rival.']
        ]
    ],
    'sova' => [
        'name' => 'SOVA',
        'role' => 'Iniciador',
        'description' => 'Sova informa al equipo con visión y precisión, preparando el terreno para que sus compañeros aprovechen cada ronda.',
        'abilities' => [
            ['name' => 'Flecha sónica', 'description' => 'Detecta enemigos ocultos con un rayo de sondeo que revela su posición.'],
            ['name' => 'Mochila de drones', 'description' => 'Envía drones para explorar zonas y pintar enemigos con información útil.'],
            ['name' => 'Puntería', 'description' => 'Marca objetivos con una flecha que se activa al impactar.'],
            ['name' => 'Rayo de Hunter', 'description' => 'Dispara un rayo que atraviesa la zona y revela todo lo que encuentra.']
        ]
    ],
    'phoenix' => [
        'name' => 'PHOENIX',
        'role' => 'Duelista',
        'description' => 'Phoenix empuja el ritmo del combate con fuego, presión y supervivencia, ideal para forzar el enfrentamiento.',
        'abilities' => [
            ['name' => 'Bola de fuego', 'description' => 'Lanza una esfera cegadora que obliga a los enemigos a reaccionar.'],
            ['name' => 'Muro de llamas', 'description' => 'Crea una barrera de fuego para bloquear rutas o forzar movimientos.'],
            ['name' => 'Rebote', 'description' => 'Revive una habilidad tras un tiempo para conservar la presión ofensiva.'],
            ['name' => 'Renacimiento', 'description' => 'Vuelve a la vida con una carga de supervivencia tras ser derribado.']
        ]
    ],
    'cypher' => [
        'name' => 'CYPHER',
        'role' => 'Centinela',
        'description' => 'Cypher convierte cada esquina en una trampa informativa, controlando la zona y vigilando cualquier avance enemigo.',
        'abilities' => [
            ['name' => 'Cámara trampa', 'description' => 'Coloca una cámara que avisa al equipo cuando un enemigo la observa.'],
            ['name' => 'Cápsula neural', 'description' => 'Lanza una cápsula que revela la ubicación de un enemigo capturado.'],
            ['name' => 'Mente inquieta', 'description' => 'Sujeta a un enemigo para ganar información crucial en el combate.'],
            ['name' => 'Jaula entrópica', 'description' => 'Encierra un área para limitar el movimiento y controlar el espacio.']
        ]
    ],
    'killjoy' => [
        'name' => 'KILLJOY',
        'role' => 'Centinela',
        'description' => 'Killjoy domina las zonas con dispositivos que ralentizan al enemigo y convierten el terreno en una trampa constante.',
        'abilities' => [
            ['name' => 'Torreta de alarma', 'description' => 'Instala una torreta automática que daña y marca a los enemigos.'],
            ['name' => 'Bomba de nanocápsulas', 'description' => 'Lanza un dispositivo que daña a quienes lo atraviesan.'],
            ['name' => 'Bot de alarma', 'description' => 'Rastrea la posición de los enemigos con un dispositivo automático.'],
            ['name' => 'Matriz de restricción', 'description' => 'Bloquea el movimiento en un área concreta con una barrera tecnológica.']
        ]
    ],
    'neon' => [
        'name' => 'NEON',
        'role' => 'Duelista',
        'description' => 'Neon domina el espacio con velocidad, presión y movilidad para virar el combate en pocos segundos.',
        'abilities' => [
            ['name' => 'Rayo rápido', 'description' => 'Lanza una descarga rápida que recorre una línea y daña al enemigo.'],
            ['name' => 'Carrera', 'description' => 'Se desplaza a gran velocidad y deja una estela de electricidad.'],
            ['name' => 'Carrera por la luz', 'description' => 'Aumenta su velocidad y la capacidad de reaccionar durante una corta ventana.'],
            ['name' => 'Sobrecarga', 'description' => 'Aumenta su alcance y presión mediante una descarga de alto voltaje.']
        ]
    ],
    'raze' => [
        'name' => 'RAZE',
        'role' => 'Duelista',
        'description' => 'Raze abre espacios con explosivos, daño directo y movilidad para abrir camino al equipo.',
        'abilities' => [
            ['name' => 'Cargador de explosivos', 'description' => 'Lanza una granada explosiva que daña y desplaza a los enemigos.'],
            ['name' => 'Bola de humo', 'description' => 'Crea una nube de humo para cubrir la retirada o el avance.'],
            ['name' => 'Boombot', 'description' => 'Envía un robot explorador que ataca a los enemigos cercanos.'],
            ['name' => 'Estallido', 'description' => 'Desata un gran ataque de área para borrar posiciones enemigas.']
        ]
    ],
    'reyna' => [
        'name' => 'REYNA',
        'role' => 'Duelista',
        'description' => 'Reyna convierte cada eliminación en ventaja para seguir presionando y cerrar la ronda con agresividad constante.',
        'abilities' => [
            ['name' => 'Despojo', 'description' => 'Consume al enemigo para recuperar vida y aumentar su velocidad.'],
            ['name' => 'Disparar', 'description' => 'Encanta su arma con una ventaja de precisión corta y concentrada.'],
            ['name' => 'Doble de reyna', 'description' => 'Imita una silueta que distrae y genera incertidumbre.'],
            ['name' => 'Muerte sagrada', 'description' => 'Aumenta el daño y la visibilidad para eliminar a múltiples enemigos.']
        ]
    ],
    'skye' => [
        'name' => 'SKYE',
        'role' => 'Iniciador',
        'description' => 'Skye lidera el avance con información, movilidad y apoyo para que el equipo se adapte al mapa con rapidez.',
        'abilities' => [
            ['name' => 'Roca lunar', 'description' => 'Revela la zona y ofrece una herramienta visual para apuntar con precisión.'],
            ['name' => 'Tigresa', 'description' => 'Presenta una herramienta para explorar y marcar áreas con visibilidad.'],
            ['name' => 'Mística', 'description' => 'Envía un animal de exploración que revela la posición de los enemigos.'],
            ['name' => 'Aceleración', 'description' => 'Crea una zona de curación y velocidad para el equipo.']
        ]
    ],
    'viper' => [
        'name' => 'VIPER',
        'role' => 'Controlador',
        'description' => 'Viper controla zonas con toxinas y visibilidad constante, obligando al enemigo a moverse de forma calculada.',
        'abilities' => [
            ['name' => 'Nube tóxica', 'description' => 'Crea una zona de humo que daña y reduce la visión del enemigo.'],
            ['name' => 'Cortina de veneno', 'description' => 'Lanza una barrera de gas para bloquear rutas y limitar la presión.'],
            ['name' => 'Tóxico', 'description' => 'Aplica daño de zona para castigar los intentos de avance.'],
            ['name' => 'Embestida', 'description' => 'Aumenta su área de control para dominar la zona durante un periodo.']
        ]
    ],
    'yoru' => [
        'name' => 'YORU',
        'role' => 'Duelista',
        'description' => 'Yoru genera caos con engaño, desorientación y rutas inesperadas para sorprender al rival.',
        'abilities' => [
            ['name' => 'Copia falsa', 'description' => 'Crea una ilusión para confundir la atención del enemigo.'],
            ['name' => 'Disparo dimensional', 'description' => 'Lanza un proyectil que se teletransporta a una posición marcada.'],
            ['name' => 'Teletransporte', 'description' => 'Se mueve rápidamente a una posición segura o favorable.'],
            ['name' => 'Ruptura dimensional', 'description' => 'Declara un área de sorpresa que obliga a reajustar la defensa.']
        ]
    ],
    'harbor' => [
        'name' => 'HARBOR',
        'role' => 'Controlador',
        'description' => 'Harbor controla el espacio con agua y barreras para forzar trayectorias y cerrar rutas de escape.',
        'abilities' => [
            ['name' => 'Cascada', 'description' => 'Tambalea al enemigo con una ola de agua que controla el avance.'],
            ['name' => 'Barrera acuática', 'description' => 'Crea una barrera que bloquea líneas de visión y rutas.'],
            ['name' => 'Muro de agua', 'description' => 'Aísla zonas y separa al enemigo con agua controlada.'],
            ['name' => 'Ráfaga de agua', 'description' => 'Aumenta el control del terreno con una gran zona de presión.']
        ]
    ],
    'iso' => [
        'name' => 'ISO',
        'role' => 'Duelista',
        'description' => 'Iso se apoya en el duelo directo y la precisión para dominar el intercambio y ponerse por encima del rival.',
        'abilities' => [
            ['name' => 'Sello de precisión', 'description' => 'Aumenta la precisión en el intercambio y refuerza el combate directo.'],
            ['name' => 'Muro de energía', 'description' => 'Genera una barrera de control para bloquear rutas y visiones.'],
            ['name' => 'Desafío', 'description' => 'Compite por el control del terreno y fuerza al enemigo a reaccionar.'],
            ['name' => 'Precisión final', 'description' => 'Lleva el duelo al límite con una ventana de control y daño decisivo.']
        ]
    ],
    'kayo' => [
        'name' => 'KAYO',
        'role' => 'Iniciador',
        'description' => 'Kayo obtiene información y reacciona con rapidez para fijar al enemigo y convertir cada ronda en una ventaja preparada.',
        'abilities' => [
            ['name' => 'Sonda', 'description' => 'Examina zonas para encontrar enemigos ocultos y preparar el combate.'],
            ['name' => 'Táctica de supresión', 'description' => 'Controla la zona para evitar que el enemigo avance con seguridad.'],
            ['name' => 'Perturbación', 'description' => 'Interfiere con la posición del rival y obliga a reaccionar.'],
            ['name' => 'Activación total', 'description' => 'Condensa el control y la información para cerrar la ronda.']
        ]
    ],
    'clove' => [
        'name' => 'CLOVE',
        'role' => 'Centinela',
        'description' => 'Clove regula el combate con control, cobertura y una presión constante que hace difícil avanzar sin plan.',
        'abilities' => [
            ['name' => 'Médula', 'description' => 'Aumenta la supervivencia y la resistencia para aguantar el intercambio.'],
            ['name' => 'Muro de humo', 'description' => 'Crea una cobertura visual para proteger avances o retiradas.'],
            ['name' => 'Semilla de presión', 'description' => 'Mantiene el área bajo control y obliga al enemigo a adaptarse.'],
            ['name' => 'Línea de tiro', 'description' => 'Prioriza el flujo de combate con una ventana de control y sincronización.']
        ]
    ],
    'fade' => [
        'name' => 'FADE',
        'role' => 'Iniciador',
        'description' => 'Fade da seguimiento al enemigo con información y presión psicológica para romper su ritmo y forzar errores.',
        'abilities' => [
            ['name' => 'Olfato', 'description' => 'Presiente la posición del enemigo y prepara el combate con información prioritaria.'],
            ['name' => 'Bola de oscuridad', 'description' => 'Lanza una herramienta de control que marca y desorienta al rival.'],
            ['name' => 'Presa', 'description' => 'Genera presión para que el enemigo tenga que reaccionar en defensa.'],
            ['name' => 'Persecución', 'description' => 'Aumenta el control de la zona y mantiene la presión sobre el objetivo.']
        ]
    ],
    'gekko' => [
        'name' => 'GEKKO',
        'role' => 'Iniciador',
        'description' => 'Gekko crea presión con apoyo táctico, movilidad y control del terreno para acompañar al equipo en cada avance.',
        'abilities' => [
            ['name' => 'Garra', 'description' => 'Lanza una una habilidad de apoyo para generar presión y cobertura.'],
            ['name' => 'Aullido', 'description' => 'Comunica información clave y ayuda a fijar al enemigo.'],
            ['name' => 'Cachorro', 'description' => 'Reforzará el apoyo con una herramienta de control cercana.'],
            ['name' => 'Rescate', 'description' => 'Ayuda al equipo a consolidar una posición con apoyo y movilidad.']
        ]
    ],
    'deadlock' => [
        'name' => 'DEADLOCK',
        'role' => 'Controlador',
        'description' => 'Deadlock cuida las zonas con barreras y dispositivos de control para evitar que el rival tome el mapa por sorpresa.',
        'abilities' => [
            ['name' => 'Malla de barrera', 'description' => 'Crea una barrera temporal para cerrar rutas y reducir opciones enemigas.'],
            ['name' => 'Torreta', 'description' => 'Instala una torreta que rastrea y daña a los enemigos que se aproximan.'],
            ['name' => 'Ancla', 'description' => 'Mantiene el área bajo control mediante una herramienta de corte de zona.'],
            ['name' => 'Ráfaga de control', 'description' => 'Fortalece el control de la zona y obliga a reaccionar al rival.']
        ]
    ],
    'miks' => [
        'name' => 'MIKS',
        'role' => 'Especialista',
        'description' => 'Miks trae una lectura técnica del combate para adaptar su presencia y responder con precisión a las situaciones del mapa.',
        'abilities' => [
            ['name' => 'Información no disponible', 'description' => 'Esta ficha aún no tiene descripciones de habilidades añadidas en el proyecto.']
        ]
    ],
    'tejo' => [
        'name' => 'TEJO',
        'role' => 'Especialista',
        'description' => 'Tejo se centra en la lectura del mapa y el control de la zona para dar opciones tácticas al equipo.',
        'abilities' => [
            ['name' => 'Información no disponible', 'description' => 'Esta ficha aún no tiene descripciones de habilidades añadidas en el proyecto.']
        ]
    ],
    'veto' => [
        'name' => 'VETO',
        'role' => 'Especialista',
        'description' => 'Veto aporta control y orden en el combate, ajustando su presencia al ritmo de la ronda.',
        'abilities' => [
            ['name' => 'Información no disponible', 'description' => 'Esta ficha aún no tiene descripciones de habilidades añadidas en el proyecto.']
        ]
    ],
    'vyse' => [
        'name' => 'VYSE',
        'role' => 'Especialista',
        'description' => 'Vyse se concentra en el control del espacio con información y adaptabilidad para cerrar cada enfrentamiento con seguridad.',
        'abilities' => [
            ['name' => 'Información no disponible', 'description' => 'Esta ficha aún no tiene descripciones de habilidades añadidas en el proyecto.']
        ]
    ],
    'waylay' => [
        'name' => 'WAYLAY',
        'role' => 'Especialista',
        'description' => 'Waylay se mueve con agilidad para ganar ángulos de visión y controlar la forma en la que el equipo toma el espacio.',
        'abilities' => [
            ['name' => 'Información no disponible', 'description' => 'Esta ficha aún no tiene descripciones de habilidades añadidas en el proyecto.']
        ]
    ]
];

$selected = $championData[$slug] ?? [
    'name' => strtoupper(str_replace(['_', '-'], ' ', $slug)),
    'role' => 'No disponible',
    'description' => 'Aún no hay una ficha detallada para este campeón en el proyecto.',
    'abilities' => [
        ['name' => 'Información no disponible', 'description' => 'No se han añadido las habilidades de este campeón todavía.']
    ]
];

$hasAbilityIcons = false;
if (in_array($slug, ['sage', 'jett', 'omen'], true)) {
    foreach ($selected['abilities'] as $index => $ability) {
        $imageFile = "habilidades/{$slug}_hab" . ($index + 1) . ".png";
        if (file_exists(__DIR__ . '/' . $imageFile)) {
            $selected['abilities'][$index]['image'] = $imageFile;
            $hasAbilityIcons = true;
        }
    }
}

$hasImage = file_exists(__DIR__ . '/' . $imagePath);
$detailImage = $hasImage ? $imagePath : 'imagenes/placeholder.png';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VALOHUB - <?= htmlspecialchars($selected['name']) ?></title>
    <link rel="stylesheet" href="style.css">
    <style>
        .detail-page {
            padding: 40px;
            max-width: 1200px;
            margin: 0 auto;
            min-height: calc(100vh - 60px - 150px);
        }

        .detail-hero {
            display: flex;
            gap: 30px;
            align-items: center;
            background: rgba(255, 255, 255, 0.06);
            border-radius: 20px;
            padding: 30px;
            border: 1px solid rgba(255, 70, 85, 0.15);
            margin-bottom: 30px;
        }

        .detail-image-container {
            flex: 1;
            min-width: 280px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #1A1A1A, #0f1923);
            border-radius: 18px;
            min-height: 320px;
        }

        .detail-image-container img {
            width: 100%;
            max-width: 380px;
            height: auto;
            object-fit: contain;
            display: block;
        }

        .detail-image-fallback {
            color: #ffffff;
            font-size: 1rem;
            text-align: center;
            padding: 20px;
        }

        .detail-copy {
            flex: 1.2;
        }

        .detail-copy h1 {
            font-family: var(--font-heading);
            font-size: 3rem;
            color: var(--primary-red);
            letter-spacing: 2px;
            text-transform: uppercase;
            margin-bottom: 12px;
        }

        .detail-role {
            display: inline-block;
            background: rgba(255, 70, 85, 0.12);
            color: white;
            padding: 8px 14px;
            border-radius: 999px;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: bold;
            margin-bottom: 16px;
        }

        .detail-description {
            color: #ffffff;
            font-size: 1.1rem;
            line-height: 1.7;
            margin-bottom: 20px;
        }

        .detail-section-title {
            font-family: var(--font-heading);
            font-size: 2rem;
            color: #ffffff;
            margin-bottom: 16px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .skills-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
        }

        .skill-card {
            background: rgba(255, 255, 255, 0.08);
            border-radius: 16px;
            padding: 20px;
            border: 1px solid rgba(255, 70, 85, 0.15);
        }

        .skill-card img {
            width: 100%;
            height: 160px;
            object-fit: contain;
            border-radius: 14px;
            margin-bottom: 16px;
            background: rgba(0, 0, 0, 0.08);
        }

        .skill-card h3 {
            color: var(--primary-red);
            font-family: var(--font-heading);
            font-size: 1.4rem;
            margin-bottom: 10px;
            text-transform: uppercase;
        }

        .skill-card p {
            color: #ffffff;
            line-height: 1.6;
        }

        @media (max-width: 900px) {
            .detail-hero {
                flex-direction: column;
            }

            .detail-copy h1 {
                font-size: 2.3rem;
            }
        }
    </style>
</head>
<body>
    <header class="main-header">
        <div class="logo-container" style="cursor: pointer;" onclick="window.location.href='index.php'">
            <img class="riot-logo" src="mapas/puño.png" width="80" height="80" alt="Puño" role="img" aria-label="Riot Games Logo">
            <div class="divider"></div>
            <span class="game-logo" role="img" aria-label="Valorant Logo">V</span>
        </div>
        <nav class="main-nav">
            <ul>
                <li><button class="nav-btn" onclick="window.location.href='champions.php'">Campeones <span class="arrow">▼</span></button></li>
                <li><button class="nav-btn" onclick="window.location.href='weapons.php'">Armas <span class="arrow">▼</span></button></li>
                <li><button class="nav-btn" onclick="window.location.href='maps.php'">Mapas <span class="arrow">▼</span></button></li>
            </ul>
        </nav>
        <div class="auth-buttons">
            <?php if (isset($_SESSION['usuario'])): ?>
                <a href="perfil.php" class="user-name" style="text-decoration: none; cursor: pointer;">
                    <?php echo $_SESSION['usuario']; ?>
                </a>
                <a href="logout.php" class="btn-text">Cerrar sesión</a>
            <?php else: ?>
                <a href="login.html" class="btn-text">Iniciar sesión</a>
                <a href="register.html" class="btn-text">Registrarse</a>
            <?php endif; ?>
        </div>
    </header>

    <main>
        <section class="detail-page">
            <div class="detail-hero">
                <div class="detail-image-container">
                    <img src="<?= htmlspecialchars($detailImage) ?>" alt="<?= htmlspecialchars($selected['name']) ?>" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                    <span class="detail-image-fallback" style="display:none;">Imagen no disponible</span>
                </div>
                <div class="detail-copy">
                    <h1><?= htmlspecialchars($selected['name']) ?></h1>
                    <div class="detail-role"><?= htmlspecialchars($selected['role']) ?></div>
                    <p class="detail-description"><?= htmlspecialchars($selected['description']) ?></p>
                </div>
            </div>

            <h2 class="detail-section-title">Habilidades</h2>
            <?php if (!$hasAbilityIcons): ?>
                <p class="detail-description">No se han añadido iconos de habilidades en el proyecto, así que la ficha se muestra con nombre y explicación.</p>
            <?php endif; ?>
            <div class="skills-grid">
                <?php foreach ($selected['abilities'] as $ability): ?>
                    <article class="skill-card">
                        <?php if (!empty($ability['image'])): ?>
                            <img src="<?= htmlspecialchars($ability['image']) ?>" alt="<?= htmlspecialchars($ability['name']) ?>">
                        <?php endif; ?>
                        <h3><?= htmlspecialchars($ability['name']) ?></h3>
                        <p><?= htmlspecialchars($ability['description']) ?></p>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
    </main>

    <footer class="main-footer">
        <div class="footer-cta">
            <h4>¿Necesitáis mas ayuda?<br>Ponte en contacto con nosotros.</h4>
            <div class="contact-info">
                <span>Valohub@gmail.com</span>
                <span>644160538</span>
            </div>
        </div>
        <div class="footer-social">
            <h4>Redes sociales</h4>
            <ul>
                <li><img class="social-icon" src="mapas/tiktok.png" width="20" height="20" alt="TikTok"> valoranthub</li>
                <li><img class="social-icon" src="mapas/Instagram.png" width="20" height="20" alt="Instagram"> valohub</li>
                <li><img class="social-icon" src="mapas/X.png" width="20" height="20" alt="X"> valoxhub</li>
            </ul>
        </div>
    </footer>
</body>
</html>

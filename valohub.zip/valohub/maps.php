<?php
session_start();
include 'conexion.php';

$initialFavorites = [];
if (isset($_SESSION['usuario_id'])) {
    $stmt = $conn->prepare("SELECT tipo, elemento FROM favoritos WHERE usuario_id = ?");
    $stmt->bind_param("i", $_SESSION['usuario_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $initialFavorites[] = $row;
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VALOHUB - Mapas</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .maps-container {
            padding: 40px;
            max-width: 1400px;
            margin: 0 auto;
            min-height: calc(100vh - 60px - 150px);
        }

        .maps-header {
            text-align: center;
            margin-bottom: 40px;
            padding-top: 20px;
        }

        .maps-header h1 {
            font-family: var(--font-heading);
            font-size: 4rem;
            color: var(--primary-red);
            letter-spacing: 2px;
            text-transform: uppercase;
        }

        .maps-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 30px;
            padding: 20px 0;
        }

        .map-card {
            background-color: var(--dark-bg);
            border-radius: 10px;
            overflow: hidden;
            border: 2px solid transparent;
            transition: transform 0.3s, border-color 0.3s;
            cursor: pointer;
            position: relative;
            height: 250px;
        }

        .map-card:hover {
            transform: translateY(-5px);
            border-color: var(--primary-red);
        }

        .map-image {
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            color: white;
            background-size: cover;
            background-position: center;
            position: relative;
            overflow: hidden;
        }

        .map-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .map-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(to top, rgba(0, 0, 0, 0.9), rgba(0, 0, 0, 0.2));
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
            padding: 20px;
            transition: background 0.3s;
        }

        .map-card:hover .map-overlay {
            background: linear-gradient(to top, rgba(0, 0, 0, 0.9), rgba(255, 70, 85, 0.2));
        }

        .map-name {
            font-family: var(--font-heading);
            font-size: 2.5rem;
            color: white;
            margin-bottom: 5px;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        .map-location {
            color: var(--text-gray);
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* Map specific placeholders */
        .bg-ascent {
            background: linear-gradient(135deg, #1A1A1A, #A3C9D8);
        }

        .bg-bind {
            background: linear-gradient(135deg, #1A1A1A, #D2A878);
        }

        .bg-haven {
            background: linear-gradient(135deg, #1A1A1A, #8F9A8A);
        }

        .bg-split {
            background: linear-gradient(135deg, #1A1A1A, #8F76B9);
        }

        .bg-icebox {
            background: linear-gradient(135deg, #1A1A1A, #B4D7E2);
        }

        .bg-breeze {
            background: linear-gradient(135deg, #1A1A1A, #E4D9B2);
        }
    </style>
</head>

<body>
    <header class="main-header">
        <div class="logo-container" style="cursor: pointer;" onclick="window.location.href='index.php'">
            <img class="riot-logo" src="mapas/puño.png" width="80" height="80" alt="Puño" role="img" aria-label="Riot Games Logo">
            <div class="divider"></div>
            <span class="game-logo" role="img" aria-label="Valorant Logo">V</span>
        </div>
        <nav class="main-nav">
            <ul>
                <li><button class="nav-btn" onclick="window.location.href='champions.php'">Campeones <span
                            class="arrow">▼</span></button></li>
                <li><button class="nav-btn" onclick="window.location.href='weapons.php'">Armas <span
                            class="arrow">▼</span></button></li>
                <li><button class="nav-btn" onclick="window.location.href='maps.php'">Mapas <span
                            class="arrow">▼</span></button></li>
            </ul>
        </nav>
        <div class="auth-buttons">

		<?php if (isset($_SESSION['usuario'])): ?>

			<a href="perfil.php" class="user-name" style="text-decoration: none; cursor: pointer;">
				<?php echo $_SESSION['usuario']; ?>
			</a>

			<a href="logout.php" class="btn-text">
				Cerrar sesión
			</a>

		<?php else: ?>

			<a href="login.html" class="btn-text">
				Iniciar sesión
			</a>

			<a href="register.html" class="btn-text">
				Registrarse
			</a>

		<?php endif; ?>

		</div>
    </header>

    <main>
        <section class="maps-container">
            <div class="maps-header">
                <h1>Escenarios</h1>
                <p style="color: var(--text-gray); font-size: 1.2rem; margin-top: 10px;">Descubre los campos de batalla
                    donde se forjan las leyendas.</p>
            </div>

            <div class="maps-grid">
                <article class="map-card" data-map="ascent">
                    <div class="map-image">
                        <img src="mapas/ascent.JPEG" alt="Ascent">
                        <div class="map-overlay">
                            <h2 class="map-name">ASCENT</h2>
                            <span class="map-location">Venecia, Italia</span>
                        </div>
                    </div>
                </article>

                <article class="map-card" data-map="bind">
                    <div class="map-image">
                        <img src="mapas/bind.JPEG" alt="Bind">
                        <div class="map-overlay">
                            <h2 class="map-name">BIND</h2>
                            <span class="map-location">Rabat, Marruecos</span>
                        </div>
                    </div>
                </article>

                <article class="map-card" data-map="heaven">
                    <div class="map-image">
                        <img src="mapas/heaven.JPEG" alt="Heaven">
                        <div class="map-overlay">
                            <h2 class="map-name">HEAVEN</h2>
                            <span class="map-location">Timbu, Bután</span>
                        </div>
                    </div>
                </article>

                <article class="map-card" data-map="split">
                    <div class="map-image">
                        <img src="mapas/split.JPEG" alt="Split">
                        <div class="map-overlay">
                            <h2 class="map-name">SPLIT</h2>
                            <span class="map-location">Tokio, Japón</span>
                        </div>
                    </div>
                </article>

                <article class="map-card" data-map="icebox">
                    <div class="map-image">
                        <img src="mapas/icebox.JPEG" alt="Icebox">
                        <div class="map-overlay">
                            <h2 class="map-name">ICEBOX</h2>
                            <span class="map-location">Isla Bennett, Rusia</span>
                        </div>
                    </div>
                </article>

                <article class="map-card" data-map="breeze">
                    <div class="map-image">
                        <img src="mapas/breeze.JPEG" alt="Breeze">
                        <div class="map-overlay">
                            <h2 class="map-name">BREEZE</h2>
                            <span class="map-location">Triángulo de las Bermudas</span>
                        </div>
                    </div>
                </article>

                <article class="map-card" data-map="lotus">
                    <div class="map-image">
                        <img src="mapas/lotus.JPEG" alt="Lotus">
                        <div class="map-overlay">
                            <h2 class="map-name">LOTUS</h2>
                            <span class="map-location">India</span>
                        </div>
                    </div>
                </article>

                <article class="map-card" data-map="sunset">
                    <div class="map-image">
                        <img src="mapas/sunset.JPEG" alt="Sunset">
                        <div class="map-overlay">
                            <h2 class="map-name">SUNSET</h2>
                            <span class="map-location">Lisboa, Portugal</span>
                        </div>
                    </div>
                </article>
            </div>
        </section>
    </main>

    <footer class="main-footer">
        <div class="footer-cta">
            <h4>¿Necesitáis mas ayuda?<br>Ponte en contacto con nosotros.</h4>
            <div class="contact-info">
                <span>Valohub@gmail.com</span>
                <span>644160538</span>
            </div>
        </div>
        <div class="footer-social">
            <h4>Redes sociales</h4>
            <ul>
                <li><img class="social-icon" src="mapas/tiktok.png" width="20" height="20" alt="TikTok"> valoranthub</li>
                <li><img class="social-icon" src="mapas/Instagram.png" width="20" height="20" alt="Instagram"> valohub</li>
                <li><img class="social-icon" src="mapas/X.png" width="20" height="20" alt="X"> valoxhub</li>
            </ul>
        </div>
    </footer>

    <script>
        window.loggedIn = <?php echo isset($_SESSION['usuario_id']) ? 'true' : 'false'; ?>;
        window.favoritePageType = 'apartado';
        window.initialFavorites = <?php echo json_encode($initialFavorites); ?>;
    </script>
    <script src="main.js?v=2"></script>
</body>

</html>
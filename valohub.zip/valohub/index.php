<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VALOHUB - Asistencia para Valorant</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header class="main-header">
        <div class="logo-container" style="cursor: pointer;" onclick="window.location.href='index.php'">
            <img class="riot-logo" src="mapas/puño.png" width="80" height="60" align="middle" alt="Puño" role="img" aria-label="Riot Games Logo">
            <div class="divider"></div>
            <span class="game-logo" role="img" aria-label="Valorant Logo"></span>
        </div>
        <nav class="main-nav">
            <ul>
                <li><button class="nav-btn" onclick="window.location.href='champions.php'">Campeones <span
                            class="arrow">▼</span></button></li>
                <li><button class="nav-btn" onclick="window.location.href='weapons.php'">Armas <span
                            class="arrow">▼</span></button></li>
                <li><button class="nav-btn" onclick="window.location.href='maps.php'">Mapas <span
                            class="arrow">▼</span></button></li>
            </ul>
        </nav>
        <div class="auth-buttons">

		<?php if (isset($_SESSION['usuario'])): ?>

			<a href="perfil.php" class="user-name" style="text-decoration: none; cursor: pointer;">
				<?php echo $_SESSION['usuario']; ?>
			</a>

			<a href="logout.php" class="btn-text">
				Cerrar sesión
			</a>

		<?php else: ?>

			<a href="login.html" class="btn-text">
				Iniciar sesión
			</a>

			<a href="register.html" class="btn-text">
				Registrarse
			</a>

		<?php endif; ?>

		</div>
    </header>

    <main>
        <!-- Seleccion de personaje -->
        <section class="hero-section">
            <div class="hero-content">
                <div class="hero-brand">
                    <h1>VALO<span class="red-text">HUB</span> <span class="fist-icon"><img src="logos/logohub.png" width="80" height="80" align="top" alt="Puño"/></span></h1>
                </div>
                <div class="hero-text">
                    <h2>Asistencia para valorant</h2>
                    <p>¡Inicia sesion para poder ser el mejor!</p>
                    <button class="cta-btn" onclick="window.location.href='login.html'">INICIAR SESIÓN</button>
                </div>
            </div>
        </section>

        <!-- Contenidos adicionales -->
        <section class="cards-container">
            <div class="card-promo-text">
                <h3>Investiga sobre tus creadores de contenido favoritos</h3>
            </div>
            <div class="cards-grid">
                <article class="card">
                    <a class="card-link" href="https://youtube.com/playlist?list=PLeHc_suXEwkf0M57S3sj32HAqoohN_tRG&si=IS7U0OS0V8tW_lyO" target="_blank" rel="noopener noreferrer">
                        <div class="card-image entertainment">
                            <img src="CuadrosInvestiga/Entretenimiento.png" alt="Entretenimiento" />
                            <span class="team-logo"></span>
                        </div>
                        <div class="card-overlay">
                            <p>Disfruta de las mejores partidas</p>
                        </div>
                    </a>
                </article>
                <article class="card">
                    <a class="card-link" href="https://youtube.com/playlist?list=PLeHc_suXEwkf1TCt6MCXQ0Z-t4C9x6oXO&si=A6fL-6Qmaf87-GvQ" target="_blank" rel="noopener noreferrer">
                        <div class="card-image tutoriales">
                            <img src="CuadrosInvestiga/Tutoriales.png" alt="Tutoriales" />
                            <span class="team-logo"></span>
                        </div>
                        <div class="card-overlay">
                            <p>Aprende y mejora tu juego</p>
                        </div>
                    </a>
                </article>
                <article class="card">
                    <a class="card-link" href="https://tips.gg/es/valorant/matches/" target="_blank" rel="noopener noreferrer">
                        <div class="card-image torneos">
                            <img src="CuadrosInvestiga/Torneos.png" alt="Torneos" />
                            <span class="team-logo"></span>
                        </div>
                        <div class="card-overlay">
                            <p>Consulta los próximos partidos</p>
                        </div>
                    </a>
                </article>
            </div>
        </section>
    </main>

    <footer class="main-footer">
        <div class="footer-cta">
            <h4>¿Necesitáis mas ayuda?<br>Ponte en contacto con nosotros.</h4>
            <div class="contact-info">
                <span>Valohub@gmail.com</span>
                <span>644160538</span>
            </div>
        </div>
        <div class="footer-social">
            <h4>Redes sociales</h4>
            <ul>
                <li><img class="social-icon" src="mapas/tiktok.png" width="30" height="30" alt="TikTok"> valoranthub</li>
                <li><img class="social-icon" src="mapas/Instagram.png" width="30" height="30" alt="Instagram"> valohub</li>
                <li><img class="social-icon" src="mapas/X.png" width="30" height="30" alt="X"> valoxhub</li>
            </ul>
        </div>
    </footer>

    <script src="main.js"></script>
</body>

</html>
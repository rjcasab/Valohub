<?php
session_start();
include 'conexion.php';

$favorites = [
    'campeon' => [],
    'arma' => [],
    'apartado' => []
];

if (isset($_SESSION['usuario_id'])) {
    $stmt = $conn->prepare("SELECT tipo, elemento FROM favoritos WHERE usuario_id = ? ORDER BY tipo, elemento");
    $stmt->bind_param("i", $_SESSION['usuario_id']);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $favorites[$row['tipo']][] = $row['elemento'];
    }

    $stmt->close();
}

$hasFavorites = !empty($favorites['campeon']) || !empty($favorites['arma']) || !empty($favorites['apartado']);

function makeSlug($name) {
    $slug = strtolower($name);
    $slug = iconv('UTF-8', 'ASCII//TRANSLIT', $slug);
    $slug = preg_replace('/[^a-z0-9]/', '', $slug);
    return $slug;
}

function getFavoriteImage($type, $item) {
    $slug = makeSlug($item);
    $basePath = __DIR__;
    $candidates = [];

    if ($type === 'campeon') {
        $candidates = ["imagenes/{$slug}.png", "imagenes/{$slug}.PNG", "imagenes/{$slug}.jpg", "imagenes/{$slug}.jpeg"];
    } elseif ($type === 'arma') {
        $candidates = ["armas/{$slug}.png", "armas/{$slug}.PNG", "armas/{$slug}.jpg", "armas/{$slug}.jpeg"];
    } elseif ($type === 'apartado') {
        $candidates = ["mapas/{$slug}.jpeg", "mapas/{$slug}.jpg", "mapas/{$slug}.PNG", "mapas/{$slug}.png"];
    }

    foreach ($candidates as $candidate) {
        if (file_exists("{$basePath}/{$candidate}")) {
            return $candidate;
        }
    }

    return '';
}

function getFavoriteCategory($type) {
    if ($type === 'campeon') {
        return 'Campeón';
    }
    if ($type === 'arma') {
        return 'Arma';
    }
    return 'Mapa';
}

function getFavoriteDisplayType($type) {
    if ($type === 'campeon') {
        return 'Campeón favorito';
    }
    if ($type === 'arma') {
        return 'Arma favorita';
    }
    return 'Mapa favorito';
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VALOHUB - Favoritos</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .favorites-container {
            padding: 40px;
            max-width: 1400px;
            margin: 0 auto;
            min-height: calc(100vh - 60px - 150px);
        }

        .favorites-header {
            text-align: center;
            margin-bottom: 40px;
            padding-top: 20px;
        }

        .favorites-header h1 {
            font-family: var(--font-heading);
            font-size: 4rem;
            color: var(--primary-red);
            letter-spacing: 2px;
            text-transform: uppercase;
        }

        .section-group {
            margin-bottom: 40px;
        }

        .section-group h2 {
            font-family: var(--font-heading);
            color: white;
            margin-bottom: 20px;
            letter-spacing: 1px;
            text-transform: uppercase;
            font-size: 2rem;
        }

        .favorites-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
            padding: 20px 0;
        }

        /* Champion card styles */
        .champion-card {
            background-color: var(--dark-bg);
            border-radius: 10px;
            overflow: hidden;
            border: 2px solid transparent;
            transition: transform 0.3s, border-color 0.3s;
            cursor: pointer;
            position: relative;
        }

        .champion-card:hover {
            transform: translateY(-5px);
            border-color: var(--primary-red);
        }

        .champion-image {
            height: 300px;
            background-color: #1a1a1a;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 5rem;
            position: relative;
            overflow: hidden;
        }

        .champion-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center;
            display: block;
            position: absolute;
            inset: 0;
        }

        .fallback-image {
            display: none;
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, #111111, #1a1a1a);
            color: white;
            font-size: 1.3rem;
            font-weight: 700;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 20px;
            z-index: 2;
        }

        .champion-info {
            padding: 20px;
            background: linear-gradient(to top, rgba(0, 0, 0, 0.65), rgba(0, 0, 0, 0.2));
            position: absolute;
            bottom: 0;
            width: 100%;
            z-index: 3;
            color: white !important;
        }

        .champion-card,
        .champion-card * {
            color: white !important;
        }

        .weapon-info {
            padding: 20px;
            background: rgba(15, 25, 35, 0.95);
            border-top: 1px solid #222;
            color: white !important;
        }

        .weapon-card,
        .weapon-card * {
            color: white !important;
        }

        .map-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(to top, rgba(0, 0, 0, 0.95), rgba(0, 0, 0, 0.25));
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
            padding: 20px;
            transition: background 0.3s;
            color: white !important;
        }

        .weapon-category {
            color: #ffffff;
        }

        .stat-label {
            color: #ffffff;
        }

        .stat-value {
            color: #ff4655;
        }

        .map-image {
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            color: white;
            background-color: #111111;
            background-size: cover;
            background-position: center;
            position: relative;
            overflow: hidden;
        }

        .map-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(to top, rgba(0, 0, 0, 0.95), rgba(0, 0, 0, 0.25));
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
            padding: 20px;
            transition: background 0.3s;
            color: white;
        }

        .champion-name {
            font-family: var(--font-heading);
            font-size: 2rem;
            color: white;
            margin-bottom: 5px;
        }

        .champion-role {
            color: var(--primary-red);
            font-weight: bold;
            font-size: 1rem;
            text-transform: uppercase;
        }

        /* Weapon card styles */
        .weapon-card {
            background-color: var(--darker-bg);
            border-radius: 10px;
            overflow: hidden;
            border: 2px solid #222;
            transition: transform 0.3s, border-color 0.3s;
            cursor: pointer;
        }

        .weapon-card:hover {
            transform: translateY(-5px);
            border-color: var(--primary-red);
        }

        .weapon-image-container {
            height: 200px;
            background: linear-gradient(180deg, #1f2326, #0f1923);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            font-size: 4rem;
            position: relative;
            overflow: hidden;
        }

        .weapon-image-container img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            display: block;
        }

        .weapon-category {
            color: #ffffff;
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 5px;
        }

        .weapon-name {
            font-family: var(--font-heading);
            font-size: 2rem;
            color: white;
            margin-bottom: 15px;
            letter-spacing: 1px;
        }

        .weapon-stats {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }

        .stat-item {
            display: flex;
            flex-direction: column;
        }

        .stat-label {
            color: #ffffff;
            font-size: 0.7rem;
            text-transform: uppercase;
        }

        .stat-value {
            color: var(--primary-red);
            font-weight: bold;
            font-size: 1.1rem;
        }

        /* Map card styles */
        .map-card {
            background-color: var(--dark-bg);
            border-radius: 10px;
            overflow: hidden;
            border: 2px solid transparent;
            transition: transform 0.3s, border-color 0.3s;
            cursor: pointer;
            position: relative;
            height: 250px;
        }

        .map-card:hover {
            transform: translateY(-5px);
            border-color: var(--primary-red);
        }

        .map-card,
        .map-card * {
            color: white !important;
        }

        .map-image {
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            color: white;
            background-size: cover;
            background-position: center;
            position: relative;
            overflow: hidden;
        }

        .map-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .map-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(to top, rgba(0, 0, 0, 0.9), rgba(0, 0, 0, 0.2));
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
            padding: 20px;
            transition: background 0.3s;
        }

        .map-card:hover .map-overlay {
            background: linear-gradient(to top, rgba(0, 0, 0, 0.9), rgba(255, 70, 85, 0.2));
        }

        .map-name {
            font-family: var(--font-heading);
            font-size: 2.5rem;
            color: white;
            margin-bottom: 5px;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        .map-location {
            color: #ffffff;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .favorite-empty {
            text-align: center;
            padding: 40px 20px;
            background: rgba(255, 255, 255, 0.06);
            border-radius: 16px;
            border: 1px dashed rgba(255, 70, 85, 0.25);
            color: var(--text-gray);
            font-size: 1.1rem;
        }

        .login-link {
            color: var(--primary-red);
            text-decoration: none;
            font-weight: bold;
        }

        @media (max-width: 768px) {
            .favorites-container {
                padding: 20px;
            }
        }
    </style>
</head>

<body>
    <header class="main-header">
        <div class="logo-container" style="cursor: pointer;" onclick="window.location.href='index.php'">
            <img class="riot-logo" src="mapas/puño.png" width="80" height="80" alt="Puño" role="img" aria-label="Riot Games Logo">
            <div class="divider"></div>
            <span class="game-logo" role="img" aria-label="Valorant Logo">V</span>
        </div>
        <nav class="main-nav">
            <ul>
                <li><button class="nav-btn" onclick="window.location.href='champions.php'">Campeones <span class="arrow">▼</span></button></li>
                <li><button class="nav-btn" onclick="window.location.href='weapons.php'">Armas <span class="arrow">▼</span></button></li>
                <li><button class="nav-btn" onclick="window.location.href='maps.php'">Mapas <span class="arrow">▼</span></button></li>
            </ul>
        </nav>
        <div class="auth-buttons">
            <?php if (isset($_SESSION['usuario'])): ?>
                <span class="user-name"><?php echo $_SESSION['usuario']; ?></span>
                <span style="color: white; margin: 0 10px;">|</span>
                <a href="favorites.php" class="btn-text">
                    FAVORITOS
                </a>

                <a href="logout.php" class="btn-text">Cerrar sesión</a>
            <?php else: ?>
                <a href="login.html" class="btn-text">Iniciar sesión</a>
                <a href="register.html" class="btn-text">Registrarse</a>
            <?php endif; ?>
        </div>
    </header>

    <main>
        <section class="favorites-container">
            <div class="favorites-header">
                <h1>Favoritos</h1>
                <p style="color: var(--text-gray); font-size: 1.2rem; margin-top: 10px;">
                    Aquí están tus campeones, apartados y armas guardadas.
                </p>
            </div>

            <?php if (!isset($_SESSION['usuario'])): ?>
                <div class="favorite-empty">
                    Debes <a class="login-link" href="login.html">iniciar sesión</a> para ver tus favoritos.
                </div>
            <?php elseif (!$hasFavorites): ?>
                <div class="favorite-empty">
                    No has marcado ningún favorito todavía. Visita Campeones, Armas o Mapas y toca la estrella para guardarlos.
                </div>
            <?php else: ?>
                <?php if (!empty($favorites['campeon'])): ?>
                    <div class="section-group">
                        <h2>Campeones favoritos</h2>
                        <div class="favorites-grid">
                            <?php foreach ($favorites['campeon'] as $item): ?>
                                <article class="champion-card">
                                    <div class="champion-image">
                                        <img src="<?php echo htmlspecialchars(getFavoriteImage('campeon', $item)); ?>" alt="<?php echo htmlspecialchars($item); ?>" onerror="this.style.display='none'; this.parentNode.querySelector('.fallback-image').style.display='flex';">
                                        <div class="fallback-image"><?php echo htmlspecialchars($item); ?></div>
                                    </div>
                                    <div class="champion-info">
                                        <h2 class="champion-name"><?php echo htmlspecialchars($item); ?></h2>
                                        <span class="champion-role"><?php echo htmlspecialchars(getFavoriteDisplayType('campeon')); ?></span>
                                    </div>
                                </article>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (!empty($favorites['arma'])): ?>
                    <div class="section-group">
                        <h2>Armas favoritas</h2>
                        <div class="favorites-grid">
                            <?php foreach ($favorites['arma'] as $item): ?>
                                <article class="weapon-card">
                                    <div class="weapon-image-container">
                                        <img src="<?php echo htmlspecialchars(getFavoriteImage('arma', $item)); ?>" alt="<?php echo htmlspecialchars($item); ?>" onerror="this.style.display='none'; this.parentNode.querySelector('.fallback-image').style.display='flex';">
                                        <div class="fallback-image"><?php echo htmlspecialchars($item); ?></div>
                                    </div>
                                    <div class="weapon-info">
                                        <div class="weapon-category"><?php echo htmlspecialchars(getFavoriteCategory('arma')); ?></div>
                                        <h2 class="weapon-name"><?php echo htmlspecialchars($item); ?></h2>
                                        <div class="weapon-stats">
                                            <div class="stat-item">
                                                <span class="stat-label">Estado</span>
                                                <span class="stat-value">Guardada</span>
                                            </div>
                                            <div class="stat-item">
                                                <span class="stat-label">Categoría</span>
                                                <span class="stat-value"><?php echo htmlspecialchars(getFavoriteCategory('arma')); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </article>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (!empty($favorites['apartado'])): ?>
                    <div class="section-group">
                        <h2>Apartados favoritos</h2>
                        <div class="favorites-grid">
                            <?php foreach ($favorites['apartado'] as $item): ?>
                                <article class="map-card">
                                    <div class="map-image">
                                        <img src="<?php echo htmlspecialchars(getFavoriteImage('apartado', $item)); ?>" alt="<?php echo htmlspecialchars($item); ?>" onerror="this.style.display='none'; this.parentNode.querySelector('.fallback-image').style.display='flex';">
                                        <div class="fallback-image"><?php echo htmlspecialchars($item); ?></div>
                                        <div class="map-overlay">
                                            <h2 class="map-name"><?php echo htmlspecialchars($item); ?></h2>
                                            <span class="map-location"><?php echo htmlspecialchars(getFavoriteDisplayType('apartado')); ?></span>
                                        </div>
                                    </div>
                                </article>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </section>
    </main>

    <footer class="main-footer">
        <div class="footer-cta">
            <h4>¿Necesitáis mas ayuda?<br>Ponte en contacto con nosotros.</h4>
            <div class="contact-info">
                <span>Valohub@gmail.com</span>
                <span>644160538</span>
            </div>
        </div>
        <div class="footer-social">
            <h4>Redes sociales</h4>
            <ul>
                <li><img class="social-icon" src="mapas/tiktok.png" width="20" height="20" alt="TikTok"> valoranthub</li>
                <li><img class="social-icon" src="mapas/Instagram.png" width="20" height="20" alt="Instagram"> valohub</li>
                <li><img class="social-icon" src="mapas/X.png" width="20" height="20" alt="X"> valoxhub</li>
            </ul>
        </div>
    </footer>

</body>

</html>

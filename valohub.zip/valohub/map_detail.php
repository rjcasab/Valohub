<?php
session_start();
include 'conexion.php';

$maps = [
    'ascent' => [
        'name' => 'Ascent',
        'image' => 'mapas/ascent.JPEG',
        'location' => 'Venecia, Italia',
        'description' => 'Ascent es un mapa con un control central muy importante. Los equipos deben dominar el medio para conectar rápido los bombsites A y B. La rotación y el uso de utilidades en los pasillos estrechos marcan la diferencia.',
        'zones' => ['Punto A', 'Punto B', 'Medio', 'Spawn atacante', 'Spawn defensor'],
        'features' => [
            'Tipo' => 'Control de medio y ejecución rápida a bombsites',
            'Número de zonas' => '5 principales',
            'Tiene medio' => 'Sí',
            'Elementos importantes' => 'Puertas dobles en medio, balcones, pasillos estrechos, Longe y Underpass para rotaciones, alturas para defender A',
        ],
        'lineups' => [
            'attack' => [
                [
                    'title' => 'Entrada A desde medio',
                    'agent' => 'Sage',
                    'description' => 'Muro en Main para cortar visión de defender A y abrir paso a la ejecución desde medio hacia A. Útil cuando el defensor juega en el jardín o en la escalera.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/ascent_attack_a_1.jpg',
                ],
                [
                    'title' => 'Control de medio con smokes',
                    'agent' => 'Brimstone',
                    'description' => 'Usa smokes en Mid Top y Mid Bottom para tomar el control central y dividir la defensa. Desde ahí puedes rotar hacia A o B según la respuesta rival.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/ascent_attack_mid_1.jpg',
                ],
            ],
            'defense' => [
                [
                    'title' => 'Defensa B de Garden',
                    'agent' => 'Viper',
                    'description' => 'Coloca la nube en Garden para retrasar la entrada enemiga y utiliza un molote para cortar Hookah. Esto obliga al atacante a gastar utilidades o a desviarse hacia el medio.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/ascent_defend_b_1.jpg',
                ],
                [
                    'title' => 'Calma en A Main',
                    'agent' => 'Omen',
                    'description' => 'Usa smokes en A Main y la sombra para forzar información antes de que los atacantes lleguen a A. Perfecto para retrasar el ataque y ganar tiempo de rotación.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/ascent_defend_a_1.jpg',
                ],
            ],
        ],
    ],
    'bind' => [
        'name' => 'Bind',
        'image' => 'mapas/bind.JPEG',
        'location' => 'Rabat, Marruecos',
        'description' => 'Bind es un mapa de rotaciones rápidas con teletransportadores que permiten cambios instantáneos entre sitios. Cada bombsite tiene líneas de ataque únicas y tiene dos rutas principales para entrar a cada punto.',
        'zones' => ['Punto A', 'Punto B', 'Medio', 'Spawn atacante', 'Spawn defensor'],
        'features' => [
            'Tipo' => 'Mapa con teletransportadores y rutas divididas',
            'Número de zonas' => '5 principales',
            'Tiene medio' => 'Sí (área central conectada al teletransporte)',
            'Elementos importantes' => 'Teletransportadores, puertas en Hookah, Cubby B, tubes y cortinas en A',
        ],
        'lineups' => [
            'attack' => [
                [
                    'title' => 'Ejecución rápida A short',
                    'agent' => 'Sova',
                    'description' => 'Recon ping en A Short y molote en la esquina de la entrada para limpiar posibles posiciones de defender. Úsalo para forzar a los defensores a retroceder.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/bind_attack_a_1.jpg',
                ],
                [
                    'title' => 'Rotación con teleport a B',
                    'agent' => 'Astra',
                    'description' => 'Coloca estrellas de Astral para facilitar la entrada a B después de usar el teletransportador, cubriendo Hookah y Garden con smokes.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/bind_attack_b_1.jpg',
                ],
            ],
            'defense' => [
                [
                    'title' => 'Control de Hookah en B',
                    'agent' => 'Omen',
                    'description' => 'Smoke Hookah y coloca sombra en B para retrasar la presión. Mantiene la línea de defensa segura y obliga a los atacantes a gastar utilidades.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/bind_defend_b_1.jpg',
                ],
                [
                    'title' => 'A corta y Sauna',
                    'agent' => 'Cypher',
                    'description' => 'Coloca la cámara en A Short y la trampa en Sauna para detectar rotaciones tempranas y frenar rápidas entradas a A.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/bind_defend_a_1.jpg',
                ],
            ],
        ],
    ],
    'heaven' => [
        'name' => 'Heaven',
        'image' => 'mapas/heaven.JPEG',
        'location' => 'Timbu, Bután',
        'description' => 'Heaven ofrece una experiencia de combate vertical con pasillos estrechos y saltos precisos. El mapa destaca por sus alturas y por la necesidad de dominar puntos clave en cada bombsite.',
        'zones' => ['Punto A', 'Punto B', 'Medio', 'Spawn atacante', 'Spawn defensor'],
        'features' => [
            'Tipo' => 'Mapa vertical con enfoque en alturas y pasillos',
            'Número de zonas' => '5 principales',
            'Tiene medio' => 'Sí',
            'Elementos importantes' => 'Cuerdas, pasillos estrechos, múltiples alturas, puertas pequeñas y balcones',
        ],
        'lineups' => [
            'attack' => [
                [
                    'title' => 'Push A por Heaven',
                    'agent' => 'Sage',
                    'description' => 'Muro en Heaven para bloquear visión desde el sitio y abrir un ángulo seguro para el equipo atacante. Ideal para ejecutar desde mid hacia A.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/heaven_attack_a_1.jpg',
                ],
                [
                    'title' => 'Entrada B desde Long',
                    'agent' => 'Breach',
                    'description' => 'Usa parpadeo para aturdir la entrada a B, empujando por Long y ganando ventaja en el primer contacto con los defensores.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/heaven_attack_b_1.jpg',
                ],
            ],
            'defense' => [
                [
                    'title' => 'Defensa de medio Baja',
                    'agent' => 'Killjoy',
                    'description' => 'Coloca torretas y nanoswams en medio para retrasar rotaciones y ganar información clave. Permite rotar a A o B con ventaja.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/heaven_defend_mid_1.jpg',
                ],
                [
                    'title' => 'Control de B por oscuro',
                    'agent' => 'Viper',
                    'description' => 'Usa el muro y la nube con Viper para negar la línea de visión de los atacantes e impedir que rompan B con facilidad.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/heaven_defend_b_1.jpg',
                ],
            ],
        ],
    ],
    'split' => [
        'name' => 'Split',
        'image' => 'mapas/split.JPEG',
        'location' => 'Tokio, Japón',
        'description' => 'Split es un mapa con enfoque en control de alturas y rutas dobles. Las defensas fuertes en escaleras y mid pueden frenar las entradas rápidas si no se coordinan bien.',
        'zones' => ['Punto A', 'Punto B', 'Medio', 'Spawn atacante', 'Spawn defensor'],
        'features' => [
            'Tipo' => 'Mapa de control de alturas y presión central',
            'Número de zonas' => '5 principales',
            'Tiene medio' => 'Sí',
            'Elementos importantes' => 'Escaleras, pasillos estrechos, cables, múltiples pisos en A y B',
        ],
        'lineups' => [
            'attack' => [
                [
                    'title' => 'A corta con humo',
                    'agent' => 'Brimstone',
                    'description' => 'Coloca un humo en A Heaven y otro en A Main para cortar líneas de visión defensivas mientras tus compañeros entran al punto.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/split_attack_a_1.jpg',
                ],
                [
                    'title' => 'Presión B desde Garden',
                    'agent' => 'Astra',
                    'description' => 'Usa estrellas para cerrar Heaven y rafters, luego entra por B con control de Garden y baños.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/split_attack_b_1.jpg',
                ],
            ],
            'defense' => [
                [
                    'title' => 'Medio controlado',
                    'agent' => 'Omen',
                    'description' => 'Usa smokes en Mid Top y Mid Bottom para dividir el mapa y retrasar tanto A como B. Ideal para rotaciones defensivas rápidas.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/split_defend_mid_1.jpg',
                ],
                [
                    'title' => 'Defensa B con cuchillas',
                    'agent' => 'Cypher',
                    'description' => 'Coloca cámaras y trampa en B para detectar entradas por Garden y Bath. Mantiene información constante sobre movimiento enemigo.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/split_defend_b_1.jpg',
                ],
            ],
        ],
    ],
    'icebox' => [
        'name' => 'Icebox',
        'image' => 'mapas/icebox.JPEG',
        'location' => 'Isla Bennett, Rusia',
        'description' => 'Icebox es un mapa de ángulos cerrados y torres elevadas. Los jugadores deben dominar tanto el control vertical como el uso de cuerdas y plataformas para moverse con seguridad.',
        'zones' => ['Punto A', 'Punto B', 'Medio', 'Spawn atacante', 'Spawn defensor'],
        'features' => [
            'Tipo' => 'Mapa vertical con áreas cerradas y plataformas',
            'Número de zonas' => '5 principales',
            'Tiene medio' => 'Sí',
            'Elementos importantes' => 'Cuerdas, alturas, torres, contenedores y pasillos estrechos',
        ],
        'lineups' => [
            'attack' => [
                [
                    'title' => 'Entrada a A con cuerdas',
                    'agent' => 'Sage',
                    'description' => 'Muro en A main y smoke en Nest para negar visión rápida. Esto permite entrar con ventaja desde la cuerda y el contenedor.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/icebox_attack_a_1.jpg',
                ],
                [
                    'title' => 'Push B desde Lobby',
                    'agent' => 'Fade',
                    'description' => 'Uso de orbes y humo para cortar Hookah y planta B. Ideal para desactivar defensores que se ocultan en las alturas.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/icebox_attack_b_1.jpg',
                ],
            ],
            'defense' => [
                [
                    'title' => 'B góndola seguro',
                    'agent' => 'Sova',
                    'description' => 'Recon dart en la góndola y un molote en B para retrasar la entrada enemiga y obtener información antes de comprometer el sitio.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/icebox_defend_b_1.jpg',
                ],
                [
                    'title' => 'A contenedores',
                    'agent' => 'Viper',
                    'description' => 'Coloca la nube en A contenedores para negar visión desde Nest y retrasar el avance atacante.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/icebox_defend_a_1.jpg',
                ],
            ],
        ],
    ],
    'breeze' => [
        'name' => 'Breeze',
        'image' => 'mapas/breeze.JPEG',
        'location' => 'Triángulo de las Bermudas',
        'description' => 'Breeze es un mapa amplio con líneas largas y muchos puntos de control. La visibilidad es clave, así como el uso de utilidades para empujar desde los sitios abiertos.',
        'zones' => ['Punto A', 'Punto B', 'Medio', 'Spawn atacante', 'Spawn defensor'],
        'features' => [
            'Tipo' => 'Mapa amplio con largas líneas de visión',
            'Número de zonas' => '5 principales',
            'Tiene medio' => 'Sí',
            'Elementos importantes' => 'Alturas muy abiertas, pasillos largos, cubiertas dispersas y múltiples entradas a cada sitio',
        ],
        'lineups' => [
            'attack' => [
                [
                    'title' => 'Torres de A',
                    'agent' => 'Sova',
                    'description' => 'Recon dart en A towers para pillaje temprano y uso de molote para despejar la línea principal. Facilita la entrada desde A main.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/breeze_attack_a_1.jpg',
                ],
                [
                    'title' => 'B cave pressure',
                    'agent' => 'Astra',
                    'description' => 'Smokes en Cave y B Hall para dividir el sitio B y defender la rotación de contrataque.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/breeze_attack_b_1.jpg',
                ],
            ],
            'defense' => [
                [
                    'title' => 'B long control',
                    'agent' => 'Omen',
                    'description' => 'Smoke B long y usa la sombra para retrasar a los atacantes. Mantiene información sobre las rutas largas del mapa.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/breeze_defend_b_1.jpg',
                ],
                [
                    'title' => 'Mid oversight',
                    'agent' => 'Killjoy',
                    'description' => 'Coloca la torreta en mid para detectar pases rápidos hacia B o rotaciones hacia A.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/breeze_defend_mid_1.jpg',
                ],
            ],
        ],
    ],
    'lotus' => [
        'name' => 'Lotus',
        'image' => 'mapas/lotus.JPEG',
        'location' => 'India',
        'description' => 'Lotus combina rutas amplias y una estructura simétrica moderna. El control de líneas medias y zonas elevadas da ventaja a quien consiga posicionarse primero.',
        'zones' => ['Punto A', 'Punto B', 'Medio', 'Spawn atacante', 'Spawn defensor'],
        'features' => [
            'Tipo' => 'Mapa moderno con espacio abierto y zonas elevadas',
            'Número de zonas' => '5 principales',
            'Tiene medio' => 'Sí',
            'Elementos importantes' => 'Patios amplios, alturas duales, pasillos conectados y puntos de salto',
        ],
        'lineups' => [
            'attack' => [
                [
                    'title' => 'A por pasillo principal',
                    'agent' => 'Brimstone',
                    'description' => 'Smokes en las entradas principales de A y una molotov para despejar la primera línea defensiva.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/lotus_attack_a_1.jpg',
                ],
                [
                    'title' => 'B rotación rápida',
                    'agent' => 'Sage',
                    'description' => 'Muro en B Alley para bloquear visión y permitir el avance del equipo hacia el sitio.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/lotus_attack_b_1.jpg',
                ],
            ],
            'defense' => [
                [
                    'title' => 'A altura segura',
                    'agent' => 'Cypher',
                    'description' => 'Cámara en A alto y trampa en entrada para recibir información de las entradas principales.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/lotus_defend_a_1.jpg',
                ],
                [
                    'title' => 'B canalización',
                    'agent' => 'Viper',
                    'description' => 'Usa nube en B para negar visión aérea y ralentizar la entrada enemiga.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/lotus_defend_b_1.jpg',
                ],
            ],
        ],
    ],
    'sunset' => [
        'name' => 'Sunset',
        'image' => 'mapas/sunset.JPEG',
        'location' => 'Lisboa, Portugal',
        'description' => 'Sunset es un mapa de estilo urbano con zonas cerradas y líneas largas. El uso de coberturas y rotaciones rápidas distingue a los equipos que dominan el punto.',
        'zones' => ['Punto A', 'Punto B', 'Medio', 'Spawn atacante', 'Spawn defensor'],
        'features' => [
            'Tipo' => 'Mapa urbano con zonas mixtas abiertas y cerradas',
            'Número de zonas' => '5 principales',
            'Tiene medio' => 'Sí',
            'Elementos importantes' => 'Pasillos laterales, balcones, coberturas dobles y acceso elevado',
        ],
        'lineups' => [
            'attack' => [
                [
                    'title' => 'A con cubierta urbana',
                    'agent' => 'Sova',
                    'description' => 'Recon en A y molote en el punto de entrada principal para despejar las posiciones más habituales.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/sunset_attack_a_1.jpg',
                ],
                [
                    'title' => 'B por calle lateral',
                    'agent' => 'Astra',
                    'description' => 'Smokes en los ángulos de B para fragmentar la defensa y abrir la entrada desde el lado menos protegido.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/sunset_attack_b_1.jpg',
                ],
            ],
            'defense' => [
                [
                    'title' => 'Control de balcón B',
                    'agent' => 'Killjoy',
                    'description' => 'Torretas en el balcón y nanoswams en la entrada para retrasar la presión enemiga y obtener información de su avance.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/sunset_defend_b_1.jpg',
                ],
                [
                    'title' => 'Medio seguro',
                    'agent' => 'Omen',
                    'description' => 'Smoke central y usa la sombra para impedir que los atacantes roten rápido entre A y B.',
                    'image' => null,
                    'hint' => 'Agregar imagen: mapas/lineups/sunset_defend_mid_1.jpg',
                ],
            ],
        ],
    ],
];

function getSlug($text) {
    $slug = strtolower(trim($text));
    $slug = preg_replace('/[^a-z0-9]/', '', $slug);
    return $slug;
}

$mapKey = isset($_GET['map']) ? getSlug($_GET['map']) : '';
$aliases = [
    'haven' => 'heaven',
];

if (isset($aliases[$mapKey])) {
    $mapKey = $aliases[$mapKey];
}

$mapInfo = $maps[$mapKey] ?? null;

if (!$mapInfo) {
    header('HTTP/1.0 404 Not Found');
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VALOHUB - Detalle de mapa</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header class="main-header">
        <div class="logo-container" style="cursor: pointer;" onclick="window.location.href='index.php'">
            <img class="riot-logo" src="mapas/puño.png" width="80" height="80" alt="Puño" role="img" aria-label="Riot Games Logo">
            <div class="divider"></div>
            <span class="game-logo" role="img" aria-label="Valorant Logo">V</span>
        </div>
        <nav class="main-nav">
            <ul>
                <li><button class="nav-btn" onclick="window.location.href='champions.php'">Campeones <span class="arrow">▼</span></button></li>
                <li><button class="nav-btn" onclick="window.location.href='weapons.php'">Armas <span class="arrow">▼</span></button></li>
                <li><button class="nav-btn" onclick="window.location.href='maps.php'">Mapas <span class="arrow">▼</span></button></li>
            </ul>
        </nav>
        <div class="auth-buttons">
            <?php if (isset($_SESSION['usuario'])): ?>
                <a href="perfil.php" class="user-name" style="text-decoration: none; cursor: pointer;">
                    <?php echo htmlspecialchars($_SESSION['usuario']); ?>
                </a>
                <a href="logout.php" class="btn-text">Cerrar sesión</a>
            <?php else: ?>
                <a href="login.html" class="btn-text">Iniciar sesión</a>
                <a href="register.html" class="btn-text">Registrarse</a>
            <?php endif; ?>
        </div>
    </header>

    <main>
        <section class="map-detail-container">
            <?php if (!$mapInfo): ?>
                <div class="map-detail-header">
                    <h1>Mapa no encontrado</h1>
                    <p>El mapa solicitado no existe o no está disponible.</p>
                    <a href="maps.php" class="back-link">← Volver a Mapas</a>
                </div>
            <?php else: ?>
                <a href="maps.php" class="back-link">← Volver a Mapas</a>
                <div class="map-detail-header">
                    <h1><?php echo htmlspecialchars($mapInfo['name']); ?></h1>
                    <p><?php echo htmlspecialchars($mapInfo['location']); ?></p>
                </div>

                <div class="map-detail-banner">
                    <img src="<?php echo htmlspecialchars($mapInfo['image']); ?>" alt="<?php echo htmlspecialchars($mapInfo['name']); ?>">
                    <div class="map-detail-content">
                        <h2>Descripción</h2>
                        <p><?php echo htmlspecialchars($mapInfo['description']); ?></p>
                        <div class="map-detail-card">
                            <h2>Características principales</h2>
                            <ul>
                                <?php foreach ($mapInfo['features'] as $label => $value): ?>
                                    <li><strong><?php echo htmlspecialchars($label); ?>:</strong> <?php echo htmlspecialchars($value); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="map-detail-grid">
                    <article class="map-detail-card">
                        <h2>Zonas principales</h2>
                        <ul>
                            <?php foreach ($mapInfo['zones'] as $zone): ?>
                                <li><?php echo htmlspecialchars($zone); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </article>

                    <article class="map-detail-card">
                        <h2>Tipo de mapa</h2>
                        <p><?php echo htmlspecialchars($mapInfo['features']['Tipo']); ?></p>
                    </article>

                    <article class="map-detail-card">
                        <h2>¿Medio?</h2>
                        <p><?php echo htmlspecialchars($mapInfo['features']['Tiene medio']); ?></p>
                    </article>
                </div>

                <div class="map-detail-card">
                    <h2>Lineups recomendados</h2>
                    <div class="lineups-grid">
                        <div class="lineup-card">
                            <h3>Atacantes</h3>
                            <?php foreach ($mapInfo['lineups']['attack'] as $lineup): ?>
                                <div class="lineup-card" style="background: rgba(255,255,255,0.04); margin-bottom: 18px; padding: 18px;">
                                    <h3><?php echo htmlspecialchars($lineup['title']); ?></h3>
                                    <div class="lineup-image-placeholder">Imagen pendiente: <?php echo htmlspecialchars($lineup['hint']); ?></div>
                                    <p><strong>Agente recomendado:</strong> <?php echo htmlspecialchars($lineup['agent']); ?></p>
                                    <p><?php echo htmlspecialchars($lineup['description']); ?></p>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="lineup-card">
                            <h3>Defensores</h3>
                            <?php foreach ($mapInfo['lineups']['defense'] as $lineup): ?>
                                <div class="lineup-card" style="background: rgba(255,255,255,0.04); margin-bottom: 18px; padding: 18px;">
                                    <h3><?php echo htmlspecialchars($lineup['title']); ?></h3>
                                    <div class="lineup-image-placeholder">Imagen pendiente: <?php echo htmlspecialchars($lineup['hint']); ?></div>
                                    <p><strong>Agente recomendado:</strong> <?php echo htmlspecialchars($lineup['agent']); ?></p>
                                    <p><?php echo htmlspecialchars($lineup['description']); ?></p>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </section>
    </main>

    <footer class="main-footer">
        <div class="footer-cta">
            <h4>¿Necesitáis mas ayuda?<br>Ponte en contacto con nosotros.</h4>
            <div class="contact-info">
                <span>Valohub@gmail.com</span>
                <span>644160538</span>
            </div>
        </div>
        <div class="footer-social">
            <h4>Redes sociales</h4>
            <ul>
                <li><img class="social-icon" src="mapas/tiktok.png" width="20" height="20" alt="TikTok"> valoranthub</li>
                <li><img class="social-icon" src="mapas/Instagram.png" width="20" height="20" alt="Instagram"> valohub</li>
                <li><img class="social-icon" src="mapas/X.png" width="20" height="20" alt="X"> valoxhub</li>
            </ul>
        </div>
    </footer>
</body>

</html>
